require 'json'

def lambda_handler(event:, context:)
  "Hello World"
end

def second_lambda_handler(event:, context:)
  "Hello Mars"
end