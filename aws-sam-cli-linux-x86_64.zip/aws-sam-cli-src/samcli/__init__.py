"""
SAM CLI version
"""

__version__ = "1.46.0"
